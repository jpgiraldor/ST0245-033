import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Objects;

public class Main {

    public static int CELL_SIZE = 100;

    public static void main(String[] args) {
        SpatialHash spatialHash = new SpatialHash();
        Scan scan = new Scan();
        ArrayList<Integer> keys = new ArrayList<>();
        try {
            scan.read(spatialHash,1000,keys);
            long l = System.currentTimeMillis();
            keys.forEach(k -> spatialHash.get(k).collision());
            System.out.println("Time " + (System.currentTimeMillis() - l));

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("Checks: " + SpatialHash.checks);
        System.out.println("Collisions " + SpatialHash.collitions);


    }
}
