
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Scan{

    int cont = 0;

    public void read(SpatialHash spatialHash, int bees, ArrayList<Integer> keys) throws FileNotFoundException {

        Scanner scanner = new Scanner(new File("DataSets/" + bees + "Bees.txt"));
        int id = 0;
        while (scanner.hasNextLine()) {

            String[] n = scanner.nextLine().split(",");
            double y = (Double.parseDouble(n[1]) * 111111.111) - 700000;
            double x = (Double.parseDouble(n[0]) * -111111.111) - 8390000;
            Bee bee = new Bee(x,y,id++);
            List<Integer> bees1 = bee.getQuadrants();
            if (!keys.contains(bees1.get(0))) keys.add(bees1.get(0));
            spatialHash.get(bees1.get(0)).addBee(bee);
            for (int i = 1; i < bees1.size(); i++) {
                if (!keys.contains(bees1.get(i))) keys.add(bees1.get(i));
                spatialHash.get(bees1.get(i)).add(bee);
            }
        }
    }

}
