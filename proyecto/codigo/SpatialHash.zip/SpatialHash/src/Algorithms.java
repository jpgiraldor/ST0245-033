import java.util.List;

public class Algorithms {

    public static double pitagorasBee(Bee a , Bee b) {
        SpatialHash.checks++;
        double res = Math.sqrt(Math.pow(Math.abs((a.getX()) - (b.getX())),2)
                + Math.pow(Math.abs((a.getY()) - (b.getY())),2));
        return res;
    }
    public static void collision(List<Bee> bees) {
        //System.out.println(bees);
        if (bees.size()> 1) {
            for (int i = 0; i < bees.size(); i++) {
                for (int j = i + 1; j < bees.size(); j++) {
                    //System.out.println(Algorithms.pitagoras(bees.get(i), bees.get(j)) <= 100);
                    if (Algorithms.pitagorasBee(bees.get(i), bees.get(j)) <= 100 && (!bees.get(j).hasCol(bees.get(i))
                            ||!bees.get(i).hasCol(bees.get(j)))) {
                        SpatialHash.collitions++;
                        bees.get(i).addCol(bees.get(j));
                        //System.out.println(get(i) + " Colisiona con " + get(j));
                    }
                }
            }
        }
    }
    public static double pitagoras(int x, int y, double x2, double y2) {
        double res = Math.sqrt(Math.pow(Math.abs(x - x2),2)
                + Math.pow(Math.abs((y - y2)),2));
        return res;
    }
}
