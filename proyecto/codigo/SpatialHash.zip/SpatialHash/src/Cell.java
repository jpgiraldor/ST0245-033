import java.util.ArrayList;
import java.util.Objects;

public class Cell extends ArrayList<Bee>{

    private int x,y;

    private SubCell topLeft,topRight,bottomLeft,bottomRight;


    public Cell(int x, int y) {
        this.x = x;
        this.y = y;
        int ch = Main.CELL_SIZE/2;
        x = x * Main.CELL_SIZE;
        y = y * Main.CELL_SIZE;
        topLeft = new SubCell(x,y,ch,ch);
        topRight = new SubCell(x + ch,y,ch,ch);
        bottomLeft = new SubCell(x,y + ch,ch,ch);
        bottomRight = new SubCell(x + ch,y + ch,ch,ch);
    }
    public void addBee(Bee bee) {
        this.add(bee);
        //System.out.println(bee.getX() + " " + bee.getY());
        topLeft.insideOf(bee);
        topRight.insideOf(bee);
        bottomLeft.insideOf(bee);
        bottomRight.insideOf(bee);
    }
    public void collision() {
        Algorithms.collision(this);
        //System.out.print(this + "{ ");
        //System.out.println(topRight + " }");
        Algorithms.collision(topLeft);
        Algorithms.collision(topRight);
        Algorithms.collision(bottomLeft);
        Algorithms.collision(bottomRight);
    }

    public void addToSubCell(Bee bee) {
        topLeft.insideOf(bee);
        topRight.insideOf(bee);
        bottomLeft.insideOf(bee);
        bottomRight.insideOf(bee);
    }

    @Override
    public int hashCode() {
        int w = Main.CELL_SIZE;
        int h = Main.CELL_SIZE;
        return Objects.hash(x,w,y,h);
    }
}
class SubCell extends ArrayList<Bee>{

    private int x,y,width,height;

    public SubCell(int x, int y, int width, int height) {
        //System.out.println(x + " " + y);
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    public void addBee(Bee bee) {
        this.add(bee);
    }
    public boolean insideOf(Bee bee) {
        //System.out.println(bee.getX() + " " +bee.getY());
        int xCenter = this.x + 25;
        int yCenter = this.y + 25;
        if (Algorithms.pitagoras(xCenter,yCenter,bee.getX(),bee.getY()) <= 100) {
            addBee(bee);
            return true;
        }
        return false;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
