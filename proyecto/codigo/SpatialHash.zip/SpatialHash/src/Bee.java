import javafx.util.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Bee {

    private double x,y;
    private final int r = 50;
    private int id;
    private List<Bee> col;

    public Bee(double x, double y, int id) {
        this.x = x;
        this.y = y;
        this.id = id;
        col = new ArrayList<>();
    }
    public List<Integer> getQuadrants() {
        int xInt = (int) x;
        int yInt = (int) y;
        int ch = Main.CELL_SIZE;
        //System.out.println(xInt + " " + yInt);
        List<Integer> quadrants = new ArrayList<>();
        quadrants.add(Objects.hash(xInt/ch,ch,yInt/ch,ch));
        quadrants.add(Objects.hash((xInt-r)/ch,ch,(yInt-r)/ch,ch));
        quadrants.add(Objects.hash((xInt+r)/ch,ch,(yInt+r)/ch,ch));
        quadrants.add(Objects.hash((xInt+r)/ch,ch,(yInt-r)/ch,ch));
        quadrants.add(Objects.hash((xInt-r)/ch,ch,(yInt+r)/ch,ch));
        //System.out.println(quadrants.stream().distinct().collect(Collectors.toList()));
        return quadrants.stream().distinct().collect(Collectors.toList());
    }
    public void addCol(Bee bee){
        col.add(bee);
    }
    public boolean hasCol(Bee bee) {
        return col.contains(bee) || bee.getCol().contains(this);
    }

    @Override
    public String toString() {
        return id + "";
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public List<Bee> getCol() {
        return col;
    }
}
