import java.util.LinkedHashMap;

public class SpatialHash extends LinkedHashMap<Integer,Cell>{

    public static int collitions = 0;
    public static int checks = 0;

    public SpatialHash() {
        for (int i = 0; i < Main.CELL_SIZE; i++) {
            for (int j = 0; j < Main.CELL_SIZE; j++) {
                Cell tmp = new Cell(i,j);
                this.put(tmp.hashCode(),tmp);
            }
        }
    }
}
